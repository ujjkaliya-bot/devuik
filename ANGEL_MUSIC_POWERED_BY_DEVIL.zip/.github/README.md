# ANGEL MUSIC 🎧

Telegram music bot with a romantic, colorful welcome experience.

## Welcome clips
Put licensed/original MP4, MOV, or WEBM clips in `DEVIL/welcome_clips/`. On each `/start`, the bot selects a clip in shuffled order and avoids repeats until the collection cycles. Two original archive videos are included as starter clips; add more licensed clips to expand the rotation.

Do not add copyrighted K-drama scene rips unless you have permission. Hindi-dubbed audio must also be authorized.
