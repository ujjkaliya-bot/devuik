from DEVIL.core.bot import DEVIL
from DEVIL.core.dir import dirr
from DEVIL.core.git import git
from DEVIL.core.userbot import Userbot
from DEVIL.misc import dbb, heroku

from SafoneAPI import SafoneAPI
from .logging import LOGGER

dirr()
git()
dbb()
heroku()

app = DEVIL()
userbot = Userbot()
api = SafoneAPI()


from .platforms import *

Apple = AppleAPI()
Carbon = CarbonAPI()
SoundCloud = SoundAPI()
Spotify = SpotifyAPI()
Resso = RessoAPI()
Telegram = TeleAPI()
YouTube = YouTubeAPI()

APP = "devilmusicbot"  # connect music api key "Dont change it"
